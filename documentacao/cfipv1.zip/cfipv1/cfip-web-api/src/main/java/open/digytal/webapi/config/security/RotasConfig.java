package open.digytal.webapi.config.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//https://www.baeldung.com/java-config-spring-security
//https://www.mkyong.com/spring-security/spring-security-password-hashing-example/
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled=true)

public class RotasConfig  extends WebSecurityConfigurerAdapter{
    //@Autowired
    //private Autenticador myAppUserDetailsService;
    @Autowired
    private BasicAuthentication myAppBasicAuthenticationEntryPoint;

    @Autowired
    private DataSource dataSource;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //http://www.baeldung.com/spring-security-expressions
        http.csrf().disable()
        .authorizeRequests()
        .antMatchers("/contas/**").permitAll()
        .antMatchers("/login/**").permitAll()
        .antMatchers("/logar/**").permitAll()
        .antMatchers("/naturezas/**").permitAll()
        .and()
        .authorizeRequests().anyRequest().authenticated()
        .antMatchers("/lancamentos/**").hasAnyRole("ADMIN")
        //.antMatchers("/cadastros/fornecedor/").hasAnyRole("ADMIN")
        //.antMatchers("/produtos/**").hasAnyRole("ADMIN","USER")
        .and().httpBasic().realmName("DIGYTAL_REALM")
        .authenticationEntryPoint(myAppBasicAuthenticationEntryPoint);
    }
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        //1
        auth.inMemoryAuthentication().withUser("admin").password("admin").roles("ADMIN","USER")
        .and().withUser("gso").password("gso").roles("USER");

        //2
        //BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        //auth.userDetailsService(myAppUserDetailsService).passwordEncoder(passwordEncoder);

        //3
    	
        /*auth.jdbcAuthentication().dataSource(dataSource)
        .usersByUsernameQuery(
                "select login, senha, habilitado from acesso_usuario where login=?")
        .authoritiesByUsernameQuery(
                "select usuario, permissoes from acesso_role where usuario=?");
*/
    }

    public static void main(String[] args) {
        BCryptPasswordEncoder bpe = new BCryptPasswordEncoder();
        String hashedPassword = bpe.encode("gso");
        System.out.println(hashedPassword);
    }
}
