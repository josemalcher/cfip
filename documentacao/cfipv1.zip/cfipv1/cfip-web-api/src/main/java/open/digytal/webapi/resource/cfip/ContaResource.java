package open.digytal.webapi.resource.cfip;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import open.digytal.core.cfip.model.Conta;
import open.digytal.core.cfip.model.Saldo;
import open.digytal.core.cfip.model.api.ContaService;
import open.digytal.core.model.Usuario;
import open.digytal.webapi.resource.Resources;

@RestController
@RequestMapping(value = "/contas")
public class ContaResource extends Resources {
    @Autowired
    private ContaService service;

    @GetMapping("/{usuario}")
    public List<Conta> listarContas(@PathVariable("usuario") String usuario){
        return service.listarContas(usuario);
    }
    @GetMapping("/{usuario}/params")
    public List<Conta> listarContas(@PathVariable("usuario") String usuario,@RequestParam(value="nome") String nome){
        return service.listarContas(usuario,nome);
    }
    @GetMapping("/")
    public List<Conta> listarContasHeader(@RequestHeader(value = "usuario") String usuario,@RequestHeader( value="nome") String nome){
        System.out.println("Filtro por Header");
        return service.listarContas(usuario,nome);
    }
    @GetMapping("/{usuario}/{id}")
    public List<Conta> listarContas(@PathVariable("usuario") String usuario,@PathVariable("id") Integer id){
        return service.listarContas(usuario,id);
    }
    @PostMapping
    public Conta incluirConta(@RequestBody Conta entidade){
        return service.incluirConta(entidade);
    }
    @PostMapping(value = "/usuarios")
    public Usuario incluirUsuario(@RequestBody Usuario entidade){
        return service.incluirUsuario(entidade);
    }
    @PutMapping
    public Conta alterar(@RequestBody Conta entidade){
        return service.alterar(entidade);
    }
    @GetMapping("/saldos/{conta}")
    public List<Saldo> listarSaldos(@PathVariable("conta") Integer conta) {
        return service.listarSaldos(conta);
    }
}
