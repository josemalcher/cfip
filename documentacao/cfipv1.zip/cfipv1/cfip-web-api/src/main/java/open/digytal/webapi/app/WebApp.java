package open.digytal.webapi.app;

import open.digytal.core.controle.Controle;
import open.digytal.util.Configuracao;
import open.digytal.util.Sistema;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

public class WebApp implements WebApplicationInitializer {

    private AnnotationConfigWebApplicationContext getContext() {
        //clean install jetty:run -Djetty.port=9999
        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
        context.setConfigLocation("open.digytal.webapi.config");

        return context;
    }

    public void onStartup(ServletContext servletContext) throws ServletException {
        //NECESSÁRIO PARA A CONFIGURAÇÃO DO PERSISTENCE.XML
        servletContext.setInitParameter(Configuracao.SOFTWARE_HOUSE, "rd");
        servletContext.setInitParameter(Configuracao.SOFTWARE, "backommerce");

        //ATIVA O PROFILE SE VAI USAR JPA OU API - AQUI É JPA
        System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, Controle.JPA);

        WebApplicationContext context = getContext();
        servletContext.addListener(new ContextLoaderListener(context));
        ServletRegistration.Dynamic dispatcher = servletContext.addServlet("DispatcherServlet",new DispatcherServlet(context));
        dispatcher.setLoadOnStartup(1);
        dispatcher.addMapping("/*");

    }
}
