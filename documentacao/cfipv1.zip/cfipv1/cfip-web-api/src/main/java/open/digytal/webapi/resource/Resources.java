package open.digytal.webapi.resource;

import javax.persistence.NoResultException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
public class Resources  {
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Error> handleDataIntegrityViolationException(RuntimeException ex){
        return handler(HttpStatus.CONFLICT, ex);
    }
    @ExceptionHandler(NoResultException.class)
    public ResponseEntity<Error> handleIllegalArgumentException(RuntimeException ex){
        return handler(HttpStatus.NOT_FOUND, ex);
    }
    private ResponseEntity<Error> handler(HttpStatus status, Exception ex){
        Error error = new Error(status.value(), ex.getMessage());
        return new ResponseEntity<Error>(error, status);
    }
}
