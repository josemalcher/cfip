package open.digytal.webapi.resource.cfip;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import open.digytal.core.cfip.model.Lancamento;
import open.digytal.core.cfip.model.api.LancamentoService;
import open.digytal.core.cfip.model.filter.CfipFiltro;
import open.digytal.core.util.JSon;
import open.digytal.util.Formatador;

@RestController
@RequestMapping(value = "/lancamentos")
public class LancamentoResource {
    @Autowired
    private LancamentoService service;

    @GetMapping(value = "/{id}")
    public Lancamento buscar(@PathVariable("id") Integer id) {
        return service.buscar(Lancamento.class,id);
    }

    @PostMapping(value = "/filtro")
    public List<Lancamento> listarLancamentos(@RequestBody CfipFiltro filtro) {
        return service.listarLancamentos(filtro);
    }
    @GetMapping(value = "/filtro/{hash}")
    public List<Lancamento> listarLancamentos(@PathVariable ("hash") String hash) {
        CfipFiltro filtro;
		try {
			System.out.println(hash);
			filtro = JSon.base64Objeto(hash, CfipFiltro.class);
			System.out.println(filtro);
			return service.listarLancamentos(filtro);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return null;
    }
    
    
    @PostMapping(value = "/previsoes/filtro")
    public List<Lancamento> listarPrevisoes(@RequestBody CfipFiltro filtro) {
    	return service.listarPrevisoes(filtro);
    }

    @GetMapping(value = "/extrato/{usuario}/{inicio}/{fim}/{conta}")
    public List<Lancamento> listarContaLancamentos(@PathVariable("usuario") String usuario,
                                                   @PathVariable("inicio") @DateTimeFormat(pattern = Formatador.FORMATO_DATA_API) Date inicio,
                                                   @PathVariable("fim") @DateTimeFormat(pattern = Formatador.FORMATO_DATA_API) Date fim,
                                                   @PathVariable("conta") Integer conta) {
        return service.listarContaLancamentos(usuario, inicio, fim, conta);
    }

    @PostMapping
    public void incluirLancamento(@RequestBody Lancamento entidade) {
        service.incluirLancamento(entidade);
    }
    @PutMapping
    public void alterarLancamento(@RequestBody Lancamento entidade) {
        service.alterar(entidade);
    }
    @GetMapping(value = "/compensar/{id}/{quitacao}")
    public void compensarLancamento(@PathVariable("id") Integer id,
                                    @PathVariable("quitacao") @DateTimeFormat(pattern = Formatador.FORMATO_DATA_API) Date quitacao) {
        service.compensarLancamento(id,quitacao);
    }

    @GetMapping(value = "/compensacao/{quitacao}/{ids}")
    public void compensarLancamento(@PathVariable("quitacao") @DateTimeFormat(pattern = Formatador.FORMATO_DATA_API) Date quitacao,@PathVariable("ids") List<Integer> ids) {
        System.out.println("Compensar Lançamentos .... ");
        Integer[] arrays = ids.toArray(new Integer[ids.size()]);
        service.compensarLancamento(quitacao,arrays);
    }
    @GetMapping(value = "/amortizar/{id}/{quitacao}/{amortizado}")
    public void amortizarLancamento(@PathVariable("id") Integer id,
                                    @PathVariable("quitacao") @DateTimeFormat(pattern = Formatador.FORMATO_DATA_API) Date quitacao,
                                    @PathVariable("amortizado") Double amortizado) {
        service.amortizarLancamento(id,quitacao,amortizado);
    }


}
