package open.digytal.webapi.resource.aut;


import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import open.digytal.core.model.Usuario;
import open.digytal.core.model.acesso.api.AcessoService;

//SE NÃO QUISER USAR BANCO DE DADOS
//@org.springframework.stereotype.Service
public class Autenticador implements UserDetailsService {
    @Autowired
    private AcessoService service;
    @Override
    public UserDetails loadUserByUsername(String login)
            throws UsernameNotFoundException {
        Usuario user = service.buscar(Usuario.class, login);
        String username = user.getLogin();
        String password = user.getSenha();
        boolean enabled = true;
        boolean accountNonExpired = true;
        boolean credentialsNonExpired = true;
        boolean accountNonLocked = true;
        Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        String roles="ROLE_ADMIN|ROLE_USER";
        for(String role: roles.split("[\\|]")) {
            authorities.add(new SimpleGrantedAuthority(role));
            System.out.println("ROLE-->" + role);
        }
        User userSecurity = new User(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
        return userSecurity;
    }
}
