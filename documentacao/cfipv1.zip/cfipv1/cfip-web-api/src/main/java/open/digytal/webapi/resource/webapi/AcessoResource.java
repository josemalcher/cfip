package open.digytal.webapi.resource.webapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import open.digytal.core.model.Sessao;
import open.digytal.core.model.acesso.api.AcessoService;

@RestController
@RequestMapping
public class AcessoResource {
    @Autowired
    private AcessoService service;

    @GetMapping("/logar/{login}/{senha}")
    public Sessao logar(@PathVariable("login")String login, @PathVariable("senha")String senha){
        Sessao sessao= service.logar(login,senha);
        return sessao;
    }
}
