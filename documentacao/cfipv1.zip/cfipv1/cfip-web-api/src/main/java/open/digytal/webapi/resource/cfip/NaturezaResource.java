package open.digytal.webapi.resource.cfip;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import open.digytal.core.cfip.model.Natureza;
import open.digytal.core.cfip.model.TipoMovimento;
import open.digytal.core.cfip.model.api.NaturezaService;

//https://spring.io/guides/tutorials/bookmarks/
@RestController
@RequestMapping(value = "/naturezas")
public class NaturezaResource  {
    @Autowired
    private NaturezaService service;

    @GetMapping("/{usuario}")
    public List<Natureza> listarNaturezas(@PathVariable("usuario") String usuario){
        return service.listarNaturezas(usuario);
    }
    @GetMapping("/{usuario}/{nome}")
    public List<Natureza> listarNaturezas(@PathVariable("usuario") String usuario,@PathVariable("nome") String nome){
        return service.listarNaturezas(usuario,nome);
    }
    @PostMapping()
    public Natureza incluirNatureza(@RequestBody Natureza entidade){
        return service.incluir(entidade);
    }
    @GetMapping("/{usuario}/movimento/{tipo}")
    public List<Natureza> listarNaturezas(@PathVariable("usuario")String usuario, @PathVariable("tipo") TipoMovimento tipo) {
        return service.listarNaturezas(usuario,tipo);
    }
	/*@Override
	public Controle getService() {
		return service;
	}*/
}
