package open.digytal;

import static org.junit.Assert.assertTrue;

import open.digytal.util.Hash;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class UilTest
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    public static void main(String[] args) {
        Hash hash = null;
        int current = 48654865;
        System.out.println("******* BASE 48 *********");
        for (int next = 1; next <= 30; next++) {
            hash = new Hash();
            hash.base48(current);
            System.out.println(hash.getId() + "--" + hash.getIntNext());
            current = hash.getIntNext();
        }
    }
}
