package open.digytal.core.cfip.util;

import java.util.List;

import open.digytal.core.cfip.model.Conta;
import open.digytal.core.cfip.model.Lancamento;
import open.digytal.core.cfip.model.TipoMovimento;
import open.digytal.core.cfip.model.Total;

public class CfipUtil {

    public static Total totais(List<Lancamento> lista) {
        return totais(lista, false);
    }

    public static Total totais(List<Lancamento> lista, boolean comTransferencia) {
        Total total = new Total();
        for (Lancamento l : lista) {
            if (comTransferencia || !l.isTransferencia())
                total.aplicar(l.getTipoMovimento() == TipoMovimento.CREDITO, l.getValor());
        }
        return total;
    }

    public static Double contaTotais(List<Conta> lista) {
        Double total = 0.0d;
        ;
        for (Conta c : lista) {
            total = total + c.getSaldo();
        }
        return total;
    }

}
