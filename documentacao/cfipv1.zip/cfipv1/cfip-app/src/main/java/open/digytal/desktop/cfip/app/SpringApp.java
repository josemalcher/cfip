package open.digytal.desktop.cfip.app;

import javax.swing.UIManager;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import open.digytal.core.config.PersistenceConfig;
import open.digytal.core.controle.Controle;
import open.digytal.core.model.Sessao;
import open.digytal.desktop.cfip.FrmCfipLogin;
import open.digytal.util.Configuracao;
import open.digytal.util.Sistema;
import open.digytal.util.desktop.DesktopApp;
import open.digytal.util.desktop.FrmConfiguracao;
import open.digytal.util.desktop.FrmLogin;

@Configuration
@ComponentScan(basePackages = {"open.digytal.desktop", "open.digytal.core.cfip.controle"})
@Component
public class SpringApp extends DesktopApp {
	private static AnnotationConfigApplicationContext context;
	private static Sessao sessao;
	public static void main(String[] args) {
		try {
			String lf = UIManager.getSystemLookAndFeelClassName();
			UIManager.setLookAndFeel(lf);
			init();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	private static void init(){
		Sistema sistema = Sistema.BACKOMMERCE;
		//isto vai ser usado no PersistenceConfig
		System.setProperty(Configuracao.SOFTWARE_HOUSE, "rd");
		System.setProperty(Configuracao.SOFTWARE, "backommerce");
		if(Configuracao.iniciarConfiguracao(sistema)){
			FrmConfiguracao.executar();
		}else {
			DesktopApp.exibirSplash();
			Configuracao configuracao = Configuracao.getInstance(sistema);
			context = new AnnotationConfigApplicationContext();
			context.getEnvironment().setActiveProfiles(configuracao.getProfile());
			if(configuracao.getProfile().equals(Controle.API))
				context.register(SpringApp.class);
			else
				context.register(SpringApp.class, PersistenceConfig.class);
			context.refresh();

			SpringApp.setConfiguracao(configuracao);
			FrmLogin login = getBean(FrmCfipLogin.class);
			login.exibir();

		}
	}
	public static AnnotationConfigApplicationContext getContext() {
		return context;
	}

	public static <T> T getBean(Class bean) {
		return (T) context.getBean(bean);
	}

	public static <T> T getBean(String bean) {
		return (T) context.getBean(bean);
	}

	public static void fecharContext() {
		((ConfigurableApplicationContext) context).close();
	}

	public static Sessao getSessao(){
		return sessao;
	}
	public static  void setSessao(Sessao param){
		sessao = param;
	}
}
