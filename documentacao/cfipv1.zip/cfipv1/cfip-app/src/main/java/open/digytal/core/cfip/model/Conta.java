package open.digytal.core.cfip.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity()
@Table(name="conta")
public class Conta implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(nullable=false,length=50)
	private String nome;
	
	@Column(nullable=false,length=20)
	private String sigla;
	
	@Column(nullable=false,length=9,precision=2)
	private Double saldo;
	
	@Column(length=9, name="custo_saldo", precision=2)
	private Double custoSaldo;
	
	@Column(nullable=false)
	private boolean excluido;
	
	@Column(name="usuario_id", nullable=false, length=30)
	private String usuario;
	
	@Column(name="si_valor",nullable=false,length=9,precision=2)
	private Double siValor;
	
	@Column(name="custo_prev",length=9,precision=2)
	private Double custoPrev;
	
	@Column(name="custo_real",length=9,precision=2)
	private Double custoReal;
	
	@Temporal(TemporalType.DATE)
	@Column(name="si_data")
	private Date siData;
	@Column(nullable=false)
	private boolean aplicacao;
	
	/*public Conta(String nome, String sigla, Double saldo) {
		super();
		this.nome = nome;
		this.sigla = sigla;
		this.saldo = saldo;
		this.sa
	}*/
	public void setAplicacao(boolean aplicacao) {
		this.aplicacao = aplicacao;
	}
	public boolean isAplicacao() {
		return aplicacao;
	}
	public Double getCustoSaldo() {
		return custoSaldo;
	}
	public void setCustoSaldo(Double custoSaldo) {
		this.custoSaldo = custoSaldo;
	}
	public Conta() {
		saldo=0.0d;
		siValor=0.0d;
		custoPrev=0.0;
		custoReal=0.0;
		siData=new Date();
		aplicacao=false;
		custoSaldo=0.0d;
	}
	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}
	public boolean isExcluido() {
		return excluido;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public Double getSaldo() {
		return saldo;
	}
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Conta other = (Conta) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public Double getSiValor() {
		return siValor;
	}

	public void setSiValor(Double siValor) {
		this.siValor = siValor;
	}

	public Date getSiData() {
		return siData;
	}

	public void setSiData(Date siData) {
		this.siData = siData;
	}
	public Double getCustoPrev() {
		return custoPrev==null ?0.0:custoPrev;
	}
	public void setCustoPrev(Double custoPrev) {
		this.custoPrev = custoPrev;
	}
	public Double getCustoReal() {
		return custoReal==null ?0.0:custoReal;
		
	}
	public void setCustoReal(Double custoReal) {
		this.custoReal = custoReal;
	}

	@Override
	public String toString() {
		return "Conta{" +
				"id=" + id +
				", nome='" + nome + '\'' +
				", sigla='" + sigla + '\'' +
				", saldo=" + saldo +
				", custoSaldo=" + custoSaldo +
				", excluido=" + excluido +
				", usuario='" + usuario + '\'' +
				", siValor=" + siValor +
				", custoPrev=" + custoPrev +
				", custoReal=" + custoReal +
				", siData=" + siData +
				", aplicacao=" + aplicacao +
				'}';
	}
}
