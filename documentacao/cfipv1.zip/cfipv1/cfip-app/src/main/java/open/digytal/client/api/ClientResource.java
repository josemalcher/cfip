package open.digytal.client.api;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import open.digytal.core.controle.Controle;
import open.digytal.core.util.Filtro;
import open.digytal.util.TipoOperacao;

public abstract class ClientResource implements Controle {
    //depois System.getProperty - https://howtodoinjava.com/spring-restful/spring-restful-client-resttemplate-example/
    protected final String URL = "http://localhost:8181/cfip-webapi";

    protected abstract ParameterizedTypeReference getListaType();

    protected abstract ParameterizedTypeReference getEntidadeType();

    public <T> T incluir(Object entidade) {
        String sufixo = getUri(entidade.getClass());
        return post(entidade,sufixo);
    }
    public <T> T alterar(Object entidade) {
        String sufixo = getUri(entidade.getClass());
        return put(entidade,sufixo);
    }
    public <T> T gravar(TipoOperacao operacao, Object entidade) {
        return null;
    }
    public <T> T buscar(Class classe, Object id) {
        String sufixo = getUri(classe);
        return get(getEntidadeType(),sufixo,id);
    }

    @Override
    public <T> List<T> listarTodos(Class classe) {
        return getLista(getListaType(), getUri(classe));
    }

    private String getUri(Class classe) {
        return classe.getSimpleName().toLowerCase() + "s";
    }

    protected String getUrl(Object... path) {
        String sufix = getPath("/",path);
        String url = String.format("%s%s", URL, sufix);
        return url;
    }
    protected String getPath(String delimiter, Object... path){
        return getPath(delimiter,Arrays.asList(path));
    }
    protected String getPath(String delimiter, List path){
        StringBuilder uri = new StringBuilder();
        path.forEach(item ->{ if (item!=null) {
            if(delimiter.equals("/"))
                uri.append(delimiter).append(item.toString());
            else {
                uri.append(item.toString()).append(delimiter);
            }
        }});
        if(!delimiter.equals("/"))
            uri.deleteCharAt(uri.length()-1);

        return uri.toString();
    }
    protected List filter(ParameterizedTypeReference type, Filtro filtro, Object... path){
    	String url = getUrl(path);
        System.out.println("FILTER --> " + url);

        RestTemplate rest = new RestTemplate();
        HttpEntity<Filtro> request = new HttpEntity<>(filtro);
        ResponseEntity<List> resposta = rest.exchange(url, HttpMethod.POST, request, type);
        List lista = resposta.getBody();
        return lista;
    }
    protected <T> T post(Object entidade, Object... path){
        String url = getUrl(path);
        System.out.println("POST --> " + url);

        RestTemplate restTemplate = new RestTemplate();
        Object result = restTemplate.postForObject( url, entidade, entidade.getClass());
        return (T) result;
    }
    protected <T> T put(Object entidade, Object... path){
        String url = getUrl(path);
        System.out.println("PUT --> " + url);

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.put( url, entidade);
        return (T) entidade;
    }
    protected <T> T get(ParameterizedTypeReference type, Object... path) {
        String url = getUrl(path);
        System.out.println("GET --> " + url);

        RestTemplate rest = new RestTemplate();
        ResponseEntity<T> resposta = rest.exchange(url, HttpMethod.GET, null, type);
        Object entidade = resposta.getBody();
        return (T) entidade;
    }
    protected List getLista(ParameterizedTypeReference type, Object... path) {
        String url = getUrl(path);
        System.out.println("GET LISTA --> " + url);

        RestTemplate rest = new RestTemplate();
        ResponseEntity<List> resposta = rest.exchange(url, HttpMethod.GET, null, type);
        List lista = resposta.getBody();
        return lista;
    }
    protected List getListaParam(ParameterizedTypeReference type, Map params, Object... path) {
    	 String url = getUrl(path);
    	 String args = (String) params.keySet().stream().map(k ->
    	    String.format("%s={%s}", k, k)
    	).collect(Collectors.joining("&"));
    	 
    	 RestTemplate restTemplate  = new RestTemplate();
         url=String.format(url+"?%s", args);
         System.out.println("GET LISTA PARAM --> " + url);
         ResponseEntity<List> resposta = restTemplate.exchange(url, HttpMethod.GET, null,type, params);
         List lista = resposta.getBody();
         return lista;
    }
}