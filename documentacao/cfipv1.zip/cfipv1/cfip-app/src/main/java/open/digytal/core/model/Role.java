package open.digytal.core.model;

import javax.persistence.*;

@Entity
@Table(name="acesso_role")
public class Role {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;

    @Column(nullable = false, length = 30)
    private String usuario;
    @Column(nullable = false, length = 70)
    private String permissoes;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPermissoes() {
        return permissoes;
    }

    public void setPermissoes(String permissoes) {
        this.permissoes = permissoes;
    }

    @Override
    public String toString() {
        return "Role{" +
                "id=" + id +
                ", usuario='" + usuario + '\'' +
                ", permissoes='" + permissoes + '\'' +
                '}';
    }
}
