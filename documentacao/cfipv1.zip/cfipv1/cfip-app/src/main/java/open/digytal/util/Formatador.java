package open.digytal.util;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Formatador {
    public static final String FORMATO_DATA_API="ddMMyy";
	public static String formatar(Date dataHora) {
    	return formatar(dataHora,"dd/MM/yyyy");
    }
    public static String formatar(Number numero) {
        return formatar(numero,"#,##0.00");
    }
    public static String formataDataApi(Date data){
	    return formatar(data, FORMATO_DATA_API);
    }
    public static String formatar(Object valor, String formato) {
        if (valor == null)
            return null;
        else {
            if(valor instanceof java.util.Date){
                SimpleDateFormat formatador = new SimpleDateFormat(formato);
                return formatador.format(valor);
            }else if(valor instanceof java.lang.Number){
                DecimalFormat formatador = new DecimalFormat(formato);
                return formatador.format(valor);
            }else return null;
        }

        /**
         * NumberFormat nf = NumberFormat.getNumberInstance(loc);
         * DecimalFormat df = (DecimalFormat)nf;
         * df.applyPattern(pattern);
         * String output = df.format(value);
         * System.out.println(pattern + " " + output + " " + loc.toString());
         *
         * DecimalFormatSymbols unusualSymbols = new DecimalFormatSymbols(currentLocale);
         * unusualSymbols.setDecimalSeparator('|');
         * unusualSymbols.setGroupingSeparator('^');
         *
         * String strange = "#,##0.###";
         * DecimalFormat weirdFormatter = new DecimalFormat(strange, unusualSymbols);
         * weirdFormatter.setGroupingSize(4);
         *
         * String bizarre = weirdFormatter.format(12345.678);
         * System.out.println(bizarre);
         *
         */
    }

    public static void main(String[] args) {
        System.out.println(formatar(1123456.789));
        System.out.println(formatar(1123,"0000000000"));
    }
}
