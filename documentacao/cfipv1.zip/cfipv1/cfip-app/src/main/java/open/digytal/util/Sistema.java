package open.digytal.util;

public enum Sistema {
	CFIP("CFIP","cfip"),
	BACKOMMERCE("backommerce","backommerce");
	;
	private String nome;
	private String sigla;
	private Sistema(String nome, String sigla) {
		this.nome = nome;
		this.sigla = sigla;
	}
	public String getNome() {
		return nome;
	}
	public String getSigla() {
		return sigla;
	}
	public String toString(){
		return sigla;
	}
}
