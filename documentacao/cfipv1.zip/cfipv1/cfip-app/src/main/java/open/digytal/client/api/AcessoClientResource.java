package open.digytal.client.api;

import java.util.List;

import org.springframework.context.annotation.Profile;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;

import open.digytal.core.controle.Controle;
import open.digytal.core.model.Sessao;
import open.digytal.core.model.acesso.api.AcessoService;

@Service
@Profile(Controle.API)
public class AcessoClientResource extends ClientResource implements AcessoService {

    @Override
    public Sessao logar(String login, String senha) {
        return get(getEntidadeType(),"logar",login,senha);
    }

    @Override
    protected ParameterizedTypeReference getListaType() {
         return new ParameterizedTypeReference<List<Sessao>>() {};
    }

    @Override
    protected ParameterizedTypeReference getEntidadeType() {
        return new ParameterizedTypeReference<Sessao>() {};
    }
}
