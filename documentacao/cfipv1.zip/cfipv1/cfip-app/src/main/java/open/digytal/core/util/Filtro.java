package open.digytal.core.util;

public interface Filtro {

}
