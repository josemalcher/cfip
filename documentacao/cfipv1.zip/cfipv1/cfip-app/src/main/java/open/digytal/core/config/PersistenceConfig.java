package open.digytal.core.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.cfg.AvailableSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement

//@PropertySource(value = { "file:/digytal/smarty/conf/config.properties" })
//@PropertySource("classpath:config.properties")
//@PropertySource(value="classpath:missing.properties", ignoreResourceNotFound=true)
@PropertySource("file:/${software_house}/${software}/conf/config.properties")
@ComponentScan(basePackages = {"open.digytal.core.persistencia","open.digytal.core.controle"})
public class PersistenceConfig {
	private static final String PERSISTENCE_UNIT = "PU";
	@Value("${db.url}")
	private String url;

	@Value("${db.driver}")
	private String driver;

	@Value("${db.user}")
	private String user;

	@Value("${db.pass}")
	private String pass;

	@Value("${db.dialect}")
	private String dialect;
	
	@Value("${db.ddl}")
	private String ddl;

	@Value("${db.showsql}")
	private String showsql;

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
		emf.setDataSource(createDataSource());
		emf.setJpaVendorAdapter(jpaVendorApapter());
		emf.setJpaProperties(getProperties());
		emf.setPersistenceUnitName(PERSISTENCE_UNIT);
		emf.setPackagesToScan("open.digytal.core.model","open.digytal.core.cfip.model");
		return emf;
	}

	@Bean
	public DataSource createDataSource() {
		DriverManagerDataSource dataSource = null;
		dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driver);
		dataSource.setUrl(url);
		dataSource.setUsername(user);
		dataSource.setPassword(pass);
		return dataSource;
	}

	private Properties getProperties() {
		Properties properties = new Properties();
		properties.put(AvailableSettings.HBM2DDL_AUTO, ddl);
		properties.put(AvailableSettings.DIALECT, dialect);
		properties.put(AvailableSettings.SHOW_SQL, showsql);
		return properties;
	}

	@Bean
	public JpaVendorAdapter jpaVendorApapter() {
		return new HibernateJpaVendorAdapter();
	}

	@Bean
	@Autowired
	public PlatformTransactionManager transactionManager(EntityManagerFactory entityManager) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManager);
		return transactionManager;
	}
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	
	
	
	/*private static final String PERSISTENCE_UNIT = "PU_RD";
	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
		emf.setDataSource(createDataSource());
		emf.setJpaVendorAdapter(jpaVendorApapter());
		emf.setJpaProperties(getProperties());
		emf.setPersistenceUnitName(PERSISTENCE_UNIT);
		emf.setPackagesToScan("rd.spring.model");
		return emf;
	}
	@Bean
	public DataSource createDataSource() {
		DriverManagerDataSource dataSource = null;
		dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@192.1.1.150:1521/r102d.raiadrogasil.com.br");
		dataSource.setUsername("a_raiabd"); dataSource.setPassword("raia");
		dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
		dataSource.setUrl("jdbc:hsqldb:hsql://localhost:5432/database");
		dataSource.setUsername("sa"); dataSource.setPassword("");
		return dataSource;
	}

	private Properties getProperties() {
		Properties properties = new Properties();
		//properties.put(AvailableSettings.DIALECT,"org.hibernate.dialect.Oracle10gDialect");
		
		properties.put(AvailableSettings.HBM2DDL_AUTO, "update");
		properties.put(AvailableSettings.DIALECT,"org.hibernate.dialect.HSQLDialect");
		properties.put(AvailableSettings.SHOW_SQL, "true");

		return properties;
	}

	@Bean
	public JpaVendorAdapter jpaVendorApapter() {
		return new HibernateJpaVendorAdapter();
	}

	@Bean
	@Autowired
	public PlatformTransactionManager transactionManager(EntityManagerFactory entityManager) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManager);
		return transactionManager;
	}
*/

	/*public static void main(String[] args) {
		final String[] dbArg = {"--database.0", "file:/gleyson/projetos/dbs/database", "--dbname.0", "database","--port","5432"};
		org.hsqldb.server.Server.main(dbArg);
		//final String[] dbArg = { "--user", "sa", "--password", "", "--url", "jdbc:hsqldb:file:/gleyson/projetos/dbs/es/database" };
		final String[] dbArgs = { "--user", "sa", "--password", "", "--url", "jdbc:hsqldb:hsql://localhost:5432/database" };
		DatabaseManagerSwing.main(dbArgs);
	}*/
}
