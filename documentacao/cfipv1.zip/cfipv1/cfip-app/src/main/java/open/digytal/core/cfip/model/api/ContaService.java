package open.digytal.core.cfip.model.api;

import java.util.List;

import open.digytal.core.cfip.model.Conta;
import open.digytal.core.cfip.model.Saldo;
import open.digytal.core.controle.Controle;
import open.digytal.core.model.Usuario;

public interface ContaService extends Controle {
    Conta incluirConta(Conta entidade);

    Object incluirSaldo(Saldo saldo, Conta conta);

    List<Conta> listarContas(String usuario);

    List<Conta> listarContas(String usuario, String nome);

    List<Conta> listarContas(String usuario, Integer id);

    List<Saldo> listarSaldos(Integer conta);

    Usuario incluirUsuario(Usuario usuario);

    //List<Contato> listarContatos(String usuario, String nome);

    //List<Contato> listarContatos(String usuario);

    //List<DespesaRapida> listarDespesasRapidas(String usuario);
}
