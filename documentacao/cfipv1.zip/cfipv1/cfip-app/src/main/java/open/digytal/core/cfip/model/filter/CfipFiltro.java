package open.digytal.core.cfip.model.filter;

import java.util.Date;

import open.digytal.core.util.Filtro;
import open.digytal.core.util.JSon;
import open.digytal.util.Texto;

public class CfipFiltro implements Filtro {
	private boolean excluido; 
	private boolean previsao;
	private String usuario;
	private Date inicio; 
	private Date fim; 
	private Integer conta;
	private Integer natureza;
	public CfipFiltro() {
		inicio = new Date();
		fim = new Date();
	}
	public boolean isExcluido() {
		return excluido;
	}
	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}
	public boolean isPrevisao() {
		return previsao;
	}
	public void setPrevisao(boolean previsao) {
		this.previsao = previsao;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Date getInicio() {
		return inicio;
	}
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}
	public Date getFim() {
		return fim;
	}
	public void setFim(Date fim) {
		this.fim = fim;
	}
	public Integer getConta() {
		return conta;
	}
	public void setConta(Integer conta) {
		this.conta = conta;
	}
	public Integer getNatureza() {
		return natureza;
	}
	public void setNatureza(Integer natureza) {
		this.natureza = natureza;
	}
	@Override
	public String toString() {
		return "CfipFiltro [excluido=" + excluido + ", previsao=" + previsao + ", usuario=" + usuario + ", inicio="
				+ inicio + ", fim=" + fim + ", conta=" + conta + ", natureza=" + natureza + "]";
	}
	public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"excluido\" : false,");
        sb.append("\"previsao\" : false,");
        sb.append("\"usuario\" : \"gso\",");
        sb.append("\"inicio\" : \"01-09-18 00:00:00\",");
        sb.append("\"fim\" : \"30-09-18 00:00:00\"");
        //sb.append("\"conta\" : null,");
        //sb.append("\"natureza\" : null,");
        sb.append("}");
       
        try {
        	 CfipFiltro filtro = JSon.objeto(sb.toString(), CfipFiltro.class);
        	 System.out.println(filtro);
			System.out.println(Texto.base64Encode(sb.toString()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
}
