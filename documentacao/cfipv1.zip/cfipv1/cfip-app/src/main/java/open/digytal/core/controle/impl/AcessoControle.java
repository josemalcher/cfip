package open.digytal.core.controle.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import open.digytal.core.controle.Controle;
import open.digytal.core.model.Sessao;
import open.digytal.core.model.Usuario;
import open.digytal.core.model.acesso.api.AcessoService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile(Controle.JPA)
public class AcessoControle extends Controlador implements AcessoService {

	@Override
	public Sessao logar(String login, String senhaMD5) {
		Query query = getEntityManager().createQuery("SELECT e FROM Usuario e WHERE e.login = :login AND e.senha = :senha");
		query.setParameter("login", login);
		query.setParameter("senha",  senhaMD5);
		Sessao sessao=null;
		try{
			Usuario usuario = (Usuario) query.getSingleResult();
			sessao = new Sessao();
			sessao.setUsuario(usuario);
		}catch (NoResultException | NonUniqueResultException nre){
			//nre.printStackTrace();
		}
		return sessao;
	}

}
