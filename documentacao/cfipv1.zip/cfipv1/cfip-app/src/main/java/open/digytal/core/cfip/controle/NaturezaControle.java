package open.digytal.core.cfip.controle;

import java.util.List;

import javax.persistence.Query;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import open.digytal.core.cfip.model.Natureza;
import open.digytal.core.cfip.model.TipoMovimento;
import open.digytal.core.cfip.model.api.NaturezaService;
import open.digytal.core.controle.Controle;
import open.digytal.core.controle.impl.Controlador;

@Service
@Profile(Controle.JPA)
public class NaturezaControle extends Controlador implements NaturezaService {
    public List<Natureza> listarNaturezas(String usuario, String nome) {
        Query query = getEntityManager().createQuery(
                "SELECT e FROM Natureza e WHERE e.excluido = false and e.usuario = :usuario AND e.nome LIKE :nome ORDER BY e.nome");
        query.setParameter("usuario", usuario);
        query.setParameter("nome", "%" + nome + "%");
        return query.getResultList();
    }

    public List<Natureza> listarNaturezas(String usuario) {
        Query query = getEntityManager().createQuery(
                "SELECT e FROM Natureza e WHERE e.excluido = false and e.usuario = :usuario ORDER BY e.tipoMovimento, e.nome");
        query.setParameter("usuario", usuario);
        return query.getResultList();
    }

    public List<Natureza> listarNaturezas(String usuario, TipoMovimento tipo) {
        Query query = getEntityManager().createQuery(
                "SELECT e FROM Natureza e WHERE e.excluido = false AND e.usuario = :usuario AND e.tipoMovimento=:tipoMovto ORDER BY e.nome");
        query.setParameter("usuario", usuario);
        query.setParameter("tipoMovto", tipo);
        return query.getResultList();
    }
}
