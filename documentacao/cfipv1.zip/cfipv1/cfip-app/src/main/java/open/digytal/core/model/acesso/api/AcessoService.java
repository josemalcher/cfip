package open.digytal.core.model.acesso.api;

import open.digytal.core.controle.Controle;
import open.digytal.core.model.Sessao;

public interface AcessoService extends Controle {
	Sessao logar(String login, String senha);
}
