package open.digytal.util.desktop.ss.evento;

import java.util.EventListener;


public interface SSAlteracaoListener extends EventListener {
    public void alteracaoListener(SSAlteracaoEvento evento);
}
