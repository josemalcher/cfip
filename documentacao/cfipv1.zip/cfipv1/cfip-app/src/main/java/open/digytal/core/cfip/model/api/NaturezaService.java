package open.digytal.core.cfip.model.api;

import java.util.List;

import open.digytal.core.cfip.model.Natureza;
import open.digytal.core.cfip.model.TipoMovimento;
import open.digytal.core.controle.Controle;

public interface NaturezaService extends Controle {
    List<Natureza> listarNaturezas(String usuario, String nome);

    List<Natureza> listarNaturezas(String usuario);

    List<Natureza> listarNaturezas(String usuario, TipoMovimento tipo);
}
