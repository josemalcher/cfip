package open.digytal.core.controle.impl;

import open.digytal.core.controle.Controle;
import open.digytal.core.persistencia.Repositorio;

import java.util.List;

import javax.persistence.EntityManager;

import open.digytal.util.TipoOperacao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class Controlador implements Controle {
    @Autowired
    private Repositorio repositorio;
    @Override
	@Transactional
    public <T> T incluir(Object entidade) {
        return repositorio.incluir(entidade);
    }

	@Override
	@Transactional
	public <T> T alterar(Object entidade) {
		return repositorio.alterar(entidade);
	}

	@Override
	@Transactional
	public <T> T gravar(TipoOperacao operacao, Object entidade) {
		if(TipoOperacao.INCLUSAO==operacao)
    	return incluir(entidade);
		else if(TipoOperacao.ALTERACAO==operacao)
			return alterar(entidade);
		else
			throw new RuntimeException("Operação inválida");
	}

	@Override
    public <T> T buscar(Class classe, Object id) {
        return repositorio.buscar(classe, id);
    }
    
	@Override
	public List listarTodos(Class classe) {
		return repositorio.listarTodos(classe);
	}
	
	//FUTURAMENTE NÃO PRECISAR
	protected Repositorio getRepositorio() {
		return repositorio;
	}
	//FUTURAMENTE NÃO PRECISAR
	protected EntityManager getEntityManager() {
		return repositorio.getEntityManager();
	}

}
