package open.digytal.core.persistencia;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class Repositorio {
	@PersistenceContext(unitName = "PU")
	private EntityManager entityManager;

	
	public <T> T buscar(Class classe, Object id) {
		return (T) entityManager.find(classe, id);
	}
	@Transactional
	public <T> T incluir(Object entidade){
		entityManager.persist(entidade);
		entityManager.flush();
		entityManager.refresh(entidade);
		return (T) entidade;
	}
	 @Transactional
	public <T> T alterar(Object entidade) {
		return (T) entityManager.merge(entidade);
	}
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public List listarTodos(Class classe){
		Query query = entityManager.createQuery("SELECT e FROM " + classe.getSimpleName() +" e");
		return query.getResultList();
	}
}
