package open.digytal.core.cfip.model.api;

import java.util.Date;
import java.util.List;

import open.digytal.core.cfip.model.Lancamento;
import open.digytal.core.cfip.model.filter.CfipFiltro;
import open.digytal.core.controle.Controle;

public interface LancamentoService extends Controle {
	List<Lancamento> listarLancamentos(CfipFiltro filtro);
	List<Lancamento> listarPrevisoes(CfipFiltro filtro);
	List<Lancamento> listarContaLancamentos(String usuario, Date inicio, Date fim, Integer conta);
	void incluirLancamento(Lancamento entidade);
	void compensarLancamento(Integer id, Date quitacao);
	void compensarLancamento(Date quitacao, Integer... ids);
	void amortizarLancamento(Integer id, Date quitacao, Double amortizado);
}
