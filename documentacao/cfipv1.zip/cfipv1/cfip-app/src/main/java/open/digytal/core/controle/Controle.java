package open.digytal.core.controle;

import open.digytal.util.TipoOperacao;

import java.util.List;

public interface Controle {
	String API = "API";
	String JPA = "JPA";
	<T> T incluir(Object entidade);
	<T> T alterar(Object entidade);
	<T> T gravar(TipoOperacao operacao, Object entidade);
	<T> T buscar(Class classe, Object id);
	<T> List<T> listarTodos(Class classe);
}
