package open.digytal.core.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="acesso_usuario")
public class Usuario {
	@Id
	@Column(length=30,nullable=false)
	private String login;
	
	@Column(length=100,nullable=false)
	private String senha;
	
	
	@Column(nullable=false,length=50)
	private String nome;
	
	@Column(nullable=false,length=80)
	private String email;
	
	@Column(length=20)
	private String telefone;
	
	@Column(name="cpf", length=20)
	private String cpf;
	public Usuario(){
		habilitado=true;
	}
	private boolean habilitado;
	private boolean excluido;

	public boolean isHabilitado() {
		return habilitado;
	}

	public void setHabilitado(boolean habilidato) {
		this.habilitado = habilitado;
	}

	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((login == null) ? 0 : login.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (login == null) {
			if (other.login != null)
				return false;
		} else if (!login.equals(other.login))
			return false;
		return true;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public boolean isExcluido() {
		return excluido;
	}
	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}

	@Override
	public String toString() {
		return "Usuario{" +
				"login='" + login + '\'' +
				", senha='" + senha + '\'' +
				", nome='" + nome + '\'' +
				", email='" + email + '\'' +
				", telefone='" + telefone + '\'' +
				", cpf='" + cpf + '\'' +
				", excluido=" + excluido +
				'}';
	}
}
