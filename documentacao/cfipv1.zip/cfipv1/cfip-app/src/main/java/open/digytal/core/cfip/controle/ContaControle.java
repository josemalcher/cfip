package open.digytal.core.cfip.controle;

import java.util.List;

import javax.persistence.Query;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import open.digytal.core.cfip.model.Categoria;
import open.digytal.core.cfip.model.Conta;
import open.digytal.core.cfip.model.Natureza;
import open.digytal.core.cfip.model.Saldo;
import open.digytal.core.cfip.model.TipoMovimento;
import open.digytal.core.cfip.model.api.ContaService;
import open.digytal.core.controle.Controle;
import open.digytal.core.controle.impl.Controlador;
import open.digytal.core.model.Usuario;

@Service
@Profile(Controle.JPA)
public class ContaControle extends Controlador implements ContaService {
    @Transactional
    public Conta incluirConta(Conta entidade) {
        getEntityManager().persist(entidade);
        getEntityManager().flush();
        getEntityManager().refresh(entidade);
        Saldo saldo = new Saldo();
        saldo.setConta(entidade);
        getEntityManager().persist(saldo);
        System.out.println("INCLUINDO A CONTA COM O PRIMEIRO SALDO");
        return entidade;
    }

    @Transactional
    public Object incluirSaldo(Saldo saldo, Conta conta) {
        getEntityManager().persist(saldo);
        conta.setSiValor(saldo.getValor());
        conta.setSiData(saldo.getData());
        return getEntityManager().merge(conta);
    }

    public List<Conta> listarContas(String usuario) {
        Query query = getEntityManager().createQuery("SELECT e FROM Conta e WHERE e.excluido = false and e.usuario = :usuario ORDER BY e.nome");
        query.setParameter("usuario", usuario);
        return query.getResultList();
    }

    public List<Conta> listarContas(String usuario, String nome) {
        Query query = getEntityManager().createQuery("SELECT e FROM Conta e WHERE e.excluido = false and e.usuario = :usuario and e.nome like :nome");
        query.setParameter("usuario", usuario);
        query.setParameter("nome", "%" + nome + "%");
        return query.getResultList();
    }

    public List<Conta> listarContas(String usuario,Integer id) {
        StringBuilder sql = new StringBuilder("SELECT e FROM Conta e WHERE e.aplicacao = false AND e.excluido = false AND saldo >0 AND  e.usuario = :usuario");
        if(id!=null && id > 0)
            sql.append(" AND e.id = :id");
        sql.append(" ORDER BY e.nome");
        Query query = getEntityManager().createQuery(sql.toString());
        query.setParameter("usuario", usuario);
        if(id!=null && id > 0)
            query.setParameter("id", id);

        return query.getResultList();
    }
    public List<Saldo> listarSaldos(Integer conta) {
        Query query = getEntityManager().createQuery("SELECT e FROM Saldo e WHERE e.conta.id = :conta ORDER BY e.data DESC");
        query.setParameter("conta", conta);
        System.out.println("LISTAR SALDOS");
        return query.getResultList();
    }


    @Transactional
    public Usuario incluirUsuario(Usuario usuario) {
        getEntityManager().persist(usuario);
        // INCLUSAO DAS CONTAS
        Conta conta = new Conta();
        conta.setNome("CARTEIRA");
        conta.setSigla("CTR");
        conta.setUsuario(usuario.getLogin());
        conta = getEntityManager().merge(conta);
        Saldo saldo = new Saldo();
        saldo.setConta(conta);
        getEntityManager().persist(saldo);

        conta = new Conta();
        conta.setNome("CONTA CORRENTE");
        conta.setSigla("CCR");
        conta.setUsuario(usuario.getLogin());
        conta = getEntityManager().merge(conta);
        saldo = new Saldo();
        saldo.setConta(conta);
        getEntityManager().persist(saldo);

        conta = new Conta();
        conta.setNome("CONTA POUPANCA");
        conta.setSigla("CPA");
        conta.setUsuario(usuario.getLogin());
        conta = getEntityManager().merge(conta);
        saldo = new Saldo();
        saldo.setConta(conta);
        getEntityManager().persist(saldo);

        // INCLUSAO DAS NATUREZAS
        Natureza natureza = new Natureza();
        natureza.setDescricao("SALDO INICIAL");
        natureza.setNome("SALDO INICIAL");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.CREDITO);
        natureza.setCategoria(Categoria.REMUNERACAO);
        getEntityManager().persist(natureza);

        natureza = new Natureza();
        natureza.setDescricao("SALARIO");
        natureza.setNome("SALARIO");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.CREDITO);
        natureza.setCategoria(Categoria.REMUNERACAO);
        getEntityManager().persist(natureza);

        natureza = new Natureza();
        natureza.setDescricao("DESPEAS");
        natureza.setNome("DESPESAS");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.DEBITO);
        natureza.setCategoria(Categoria.DESPESA);
        getEntityManager().persist(natureza);

        natureza = new Natureza();
        natureza.setDescricao("TRANSFERENCIA");
        natureza.setNome("TRANSFERENCIA");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.TRANSFERENCIA);
        natureza.setCategoria(Categoria.TRANSACOES);
        getEntityManager().persist(natureza);

        natureza = new Natureza();
        natureza.setDescricao("ESTORNO DA TRANSFERENCIA");
        natureza.setNome("ESTORNO");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.TRANSFERENCIA);
        getEntityManager().persist(natureza);

        return usuario;
    }
    
    
    /*public interface ContaControle extends JpaRepository<Conta, Integer> {
    	//1
    	public Conta findById(Integer id);
    	//2
    	public List<Conta> findByUsuarioAndNome(Integer usuario, String nome);
    	//3
    	@Query(nativeQuery=false, value="SELECT e FROM Conta e WHERE e.excluido = false and e.usuario = :usuario and e.nome like :nome")
    	public List<Conta> listar(@Param("usuario") Integer usuario, @Param("nome") String nome);
    	//4 e ... - UsuarioRepositorio
    }
    */
}
