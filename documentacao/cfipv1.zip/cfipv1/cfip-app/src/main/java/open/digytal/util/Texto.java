package open.digytal.util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Base64;

public class Texto {
	public static String md5(String texto) throws Exception {
    	MessageDigest m=MessageDigest.getInstance("MD5");
        m.update(texto.getBytes(),0,texto.length());
        String md5=new BigInteger(1,m.digest()).toString(16);
        return md5;
    }
    public static String base64Encode(String texto) throws Exception{
        String resultado = Base64.getEncoder().encodeToString(texto.getBytes());
        return resultado;
	}
    public static String base64Decore(String encoded) throws Exception{
        byte[] bytes = Base64.getDecoder().decode(encoded);
        String resultado = new String(bytes);
        return resultado;
    }

    public static void main(String[] args) throws  Exception {
        System.out.println(md5("gso"));
    }
    
}
