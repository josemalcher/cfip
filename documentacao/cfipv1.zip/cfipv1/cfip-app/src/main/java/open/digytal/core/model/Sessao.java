package open.digytal.core.model;

import java.util.Date;

public class Sessao {
    private Usuario usuario;
    private Date inicio;
    public Sessao(){
        this.inicio=new Date();
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    @Override
    public String toString() {
        return "Sessao{" +
                "usuario=" + usuario +
                ", inicio=" + inicio +
                '}';
    }
}
