package open.digytal.util;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DataHora {
	public static Locale LOCALIZACAO = new Locale("pt", "BR");
	public static int DIA=Calendar.DAY_OF_MONTH;
	public static int MES=Calendar.MONTH;
	public static int ANO=Calendar.YEAR;
	
	
	public static int get(Date data, int atributo, Locale localizacao) {
		Calendar calendar = Calendar.getInstance(localizacao);
		calendar.setTime(data);
		int get = calendar.get(atributo);
		return get;
	}
	public static int get(Date data, int atributo) {
		return get(data, atributo, LOCALIZACAO);
	}
	public static int dia(Date data) {
		return get(data,DIA);
	}
	public static int mes(Date data) {
		return get(data,MES)+1;
	}
	public static int ano(Date data) {
		return get(data,ANO);
	}
	public static int periodo(Date data) {
		return Integer.valueOf(Formatador.formatar(ano(data),"0000") + Formatador.formatar(mes(data),"00"));
	}
	public static void main(String[] args) {
		Date data = new Date();
		System.out.println(data);
		System.out.println(dia(data));
		System.out.println(periodo(data));
	}
	
}
