package open.digytal.util.desktop.ss.evento;

import java.util.EventListener;


public interface SSPesquisaListener extends EventListener {
    public void pesquisaListener(SSPesquisaEvento evento);
}
