package open.digytal.util.desktop;

import open.digytal.util.Configuracao;

public class DesktopApp {
    private static Splash splash;
    private static Configuracao configuracao;
    public static void exibirSplash() {
        splash = new Splash();
        splash.setVisible(true);
    }
    public static void fecharSplash() {
        splash.dispose();
    }

    public static Configuracao getConfiguracao() {
        return configuracao;
    }

    public static void setConfiguracao(Configuracao config) {
        configuracao = config;
    }


}
