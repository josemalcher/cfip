package open.digytal.core.util;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import open.digytal.util.Texto;

public class JSon {
	//https://www.baeldung.com/jackson-serialize-dates
	public static <T> T base64Objeto(String hash, Class classe)throws  Exception{
		String string = Texto.base64Decore(hash);
		System.out.println(string);
		return objeto(string, classe);
	}
    public static <T> T objeto(String string,Class classe) throws  Exception{
    	SimpleDateFormat df = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
    	ObjectMapper mapper = new ObjectMapper();
        //JSON from file to Object
        //User user = mapper.readValue(new File("c:\\user.json"), User.class);
        //JSON from String to Object
        mapper.setDateFormat(df);
    	Object objeto = mapper.readValue(string, classe);
        return (T) objeto;
    }
    public static String string(Object objeto) throws Exception{
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(objeto);
        return json;
    }
    
}
