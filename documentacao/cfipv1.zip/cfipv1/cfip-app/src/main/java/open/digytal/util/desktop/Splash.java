package open.digytal.util.desktop;

import open.digytal.util.Imagem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Splash extends JFrame {
    private JLabel logotipo;
    public Splash() {

        logotipo = new JLabel(Imagem.png( "splash"));
        getContentPane().add(logotipo, BorderLayout.CENTER);
        logotipo.setBorder(BorderFactory.createEtchedBorder());
        JLabel lblVersao = new JLabel("RD - Versão: 1.0 - Raia Drograsil");
        lblVersao.setBorder(BorderFactory.createEtchedBorder());
        lblVersao.setFont(new Font("Tahoma", Font.BOLD, 11));
        lblVersao.setForeground(Color.BLUE);
        lblVersao.setHorizontalAlignment(SwingConstants.CENTER);
        getContentPane().add(lblVersao, BorderLayout.SOUTH);
        setSize(400,300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
