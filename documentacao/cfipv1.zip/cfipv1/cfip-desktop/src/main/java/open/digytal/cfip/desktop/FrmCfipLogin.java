package open.digytal.cfip.desktop;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import open.digytal.cfip.desktop.app.SpringApp;
import open.digytal.core.model.Sessao;
import open.digytal.core.model.acesso.api.AcessoService;
import open.digytal.util.desktop.FrmLogin;
import open.digytal.util.desktop.ss.SSMensagem;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FrmCfipLogin extends FrmLogin {
	@Autowired
	private AcessoService service;

	public FrmCfipLogin() {
		super.logar(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logarAction();
			}
		});
	}

	private void logarAction() {
		try {
			Sessao sessao = service.logar(getLogin(), getSenhaMD5());
            if(sessao==null){
            	SSMensagem.avisa("Usuário não localizado");
            	FrmUsuario frm = SpringApp.getBean(FrmUsuario.class);
            	frm.setVisible(true);
			}else {
            	SpringApp.setSessao(sessao);
				MDICfip mdi = SpringApp.getBean(MDICfip.class);
				mdi.setConfiguracao(SpringApp.getConfiguracao());
				mdi.exibirSessao(sessao.getUsuario().getLogin(), sessao.getUsuario().getNome());
				this.dispose();
				mdi.setVisible(true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
