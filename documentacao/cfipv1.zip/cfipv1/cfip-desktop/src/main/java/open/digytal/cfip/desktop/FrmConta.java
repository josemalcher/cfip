package open.digytal.cfip.desktop;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import open.digytal.cfip.desktop.app.SpringApp;
import open.digytal.core.cfip.model.Conta;
import open.digytal.core.cfip.model.api.ContaService;
import open.digytal.util.Formato;
import open.digytal.util.desktop.Formulario;
import open.digytal.util.desktop.ss.SSBotao;
import open.digytal.util.desktop.ss.SSCampoNumero;
import open.digytal.util.desktop.ss.SSCampoTexto;
import open.digytal.util.desktop.ss.SSMensagem;

@Component
public class FrmConta extends Formulario {
	@Autowired
	private ContaService dao;
	private SSCampoTexto txtNome = new SSCampoTexto();
	private SSCampoTexto txtSigla = new SSCampoTexto();
	private SSCampoNumero txtPrevisto = new SSCampoNumero();

	// bototes
	private SSBotao cmdFechar = new SSBotao();
	private SSBotao cmdSalvar = new SSBotao();
	
	private Conta entidade;
	private final JCheckBox chkAplicacao = new JCheckBox("Aplicação ?");
	public FrmConta() {
		init();
	}
	
	private void init() {
		// CABECALHO
		setTitulo("Conta");
		setDescricao("Cadastro das contas do sistema");

		txtNome.setRotulo("Nome");
		txtSigla.setRotulo("Sigla");
		txtPrevisto.setRotulo("Previsto");

		cmdSalvar.setText("Salvar");
		cmdFechar.setText("Fechar");
		txtPrevisto.setFormato(Formato.MOEDA);

		//
		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.gridwidth = 3;
		gbc_txtNome.insets = new Insets(5, 5, 5, 0);
		gbc_txtNome.fill = GridBagConstraints.BOTH;
		gbc_txtNome.gridx = 0;
		gbc_txtNome.gridy = 0;
		getConteudo().add(txtNome, gbc_txtNome);

		//
		GridBagConstraints gbc_txtSigla = new GridBagConstraints();
		gbc_txtSigla.gridwidth = 3;
		gbc_txtSigla.insets = new Insets(5, 5, 5, 0);
		gbc_txtSigla.fill = GridBagConstraints.BOTH;
		gbc_txtSigla.gridx = 0;
		gbc_txtSigla.gridy = 1;
		getConteudo().add(txtSigla, gbc_txtSigla);

		//
		GridBagConstraints gbc_txtPrevisto = new GridBagConstraints();
		gbc_txtPrevisto.weightx = 1.0;
		gbc_txtPrevisto.insets = new Insets(5, 5, 0, 5);
		gbc_txtPrevisto.fill = GridBagConstraints.BOTH;
		gbc_txtPrevisto.gridx = 0;
		gbc_txtPrevisto.gridy = 2;
		getConteudo().add(txtPrevisto, gbc_txtPrevisto);
		
		GridBagConstraints gbc_chkAplicacao = new GridBagConstraints();
		gbc_chkAplicacao.anchor = GridBagConstraints.SOUTHWEST;
		gbc_chkAplicacao.fill = GridBagConstraints.HORIZONTAL;
		gbc_chkAplicacao.gridx = 1;
		gbc_chkAplicacao.gridy = 2;
		getConteudo().add(chkAplicacao, gbc_chkAplicacao);

		// rodape
		getRodape().add(cmdSalvar);
		getRodape().add(cmdFechar);
		// métodos
		cmdFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sair();
			}
		});
		cmdSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salvar();
			}
		});
	}
	@Override
	public void setEntidade(Object conta) {
		this.entidade=(Conta) conta;
		if(entidade==null) 
			novo();
		else
			atribuir();
	}
	private void atribuir() {
		try {
			txtNome.requestFocus();
			txtNome.setValue(entidade.getNome());
			txtSigla.setText(entidade.getSigla());
			txtPrevisto.setValue(entidade.getCustoPrev());
			chkAplicacao.setSelected(entidade.isAplicacao());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void novo() {
		entidade = new Conta();
		atribuir();
	}
	private void sair() {
		super.cancelar();
	}
	private void salvar() {
		try {
			if (entidade == null) {
				entidade = new Conta();
			}
			entidade.setNome(txtNome.getText());
			entidade.setSigla(txtSigla.getText());
			entidade.setCustoPrev(txtPrevisto.getDouble());
			entidade.setAplicacao(chkAplicacao.isSelected());
			entidade.setUsuario(SpringApp.getSessao().getUsuario().getLogin());

			if (entidade.getNome() == null || entidade.getNome().isEmpty() || entidade.getSigla() == null
					|| entidade.getSigla().isEmpty()) {
				SSMensagem.avisa("Dados incompletos");
				return;
			}
			
			if(entidade.getId()==null)
				dao.incluirConta(entidade);
			else
				dao.alterar(entidade);
			
			SSMensagem.informa("Conta registrada com sucesso!!");
			novo();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
