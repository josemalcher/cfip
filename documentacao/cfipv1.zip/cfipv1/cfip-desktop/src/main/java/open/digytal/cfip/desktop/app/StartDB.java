package open.digytal.cfip.desktop.app;

import org.hsqldb.util.DatabaseManagerSwing;

import open.digytal.util.Sistema;

public class StartDB {
	public static void main(String[] args) {
		String url="file:/digytal/smarty/database/smartydb";
		Sistema sistema = Sistema.CFIP;
		if(sistema==Sistema.CFIP)
			url="file:/digytal/cfip/database/cfipdb";
		final String[] dbArg = {"--database.0", url, "--dbname.0", "database","--port","5433"};
		org.hsqldb.server.Server.main(dbArg);
		//final String[] dbArg = { "--user", "sa", "--password", "", "--url", "jdbc:hsqldb:file:/gleyson/projetos/dbs/es/database" };
		final String[] dbArgs = { "--user", "sa", "--password", "sa", "--url", "jdbc:hsqldb:hsql://localhost:5433/database" };
		DatabaseManagerSwing.main(dbArgs);
	}
}
// org/hsqldb/server/Server : Unsupported major.minor version 52.0