package open.digytal.persistencia;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import open.digytal.util.Filtro;

@Repository
public class Repositorio {
	@PersistenceContext
	private EntityManager entityManager;
	public <T> T alterar(Object entidade) {
		return (T) entityManager.merge(entidade);
	}
	public <T> T incluir(Object entidade){
		entityManager.persist(entidade);
		entityManager.flush();
		entityManager.refresh(entidade);
		return (T) entidade;
	}
	public <T> T buscar(Class classe, Object id) {
		return (T) entityManager.find(classe, id);
	}
	public List converter(String sql, Class clazz, List<Object[]> registros) {
		List lista = new ArrayList();
		sql = sql.replaceAll("SELECT", "");
		String[] campos = sql.split("\\,");
		try {
			for (Object[] row : registros) {
				int c = 0;
				Object item = clazz.newInstance();
				for (String campo : campos) {
					String alias = campo.split("AS")[1];
					Class type = clazz.getMethod("get" + alias.trim()).getReturnType();
					Method metodo = clazz.getMethod("set" + alias.trim(), type);
					invoke(item, metodo, row[c++]);
				}
				lista.add(item);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return lista;
	}
	public EntityManager getEntityManager() {
		return entityManager;
	}
	private void invoke(Object objecto, Method metodo, Object value) throws Exception {
		if (value != null) {
			if (value instanceof String)
				metodo.invoke(objecto, value.toString());
			else if (value instanceof Integer)
				metodo.invoke(objecto, Integer.valueOf(value.toString()));
			else if (value instanceof Double)
				metodo.invoke(objecto, Double.valueOf(value.toString()));
		}
	}

	public <T> List<T> listar(Class classe, Filtro... filtros) {
		return listar(classe, Arrays.asList(filtros));
	}

	public <T> List<T> listar(Class classe, List<Filtro> filtros) {
		JPAQL jpaql = new JPAQL(entityManager, classe.getName());
		jpaql.setFiltros(filtros);
		return jpaql.listar();
	}

	public <T> T buscar(Class classe, Filtro... filtros) {
		List<T> lista = listar(classe, filtros);
		if (lista != null && lista.size() > 0)
			return (T) lista.get(0);
		else
			return null;
	}
}
