package open.digytal.util.enums;

public interface EnumeracaoStr extends Enumeracao {
	String getCodigo();
}

