package open.digytal.util.desktop.ss;

public interface SSTextoComponente extends SSComponente {
    public void setSelecionarAoEntrar(boolean selecionarAoEntrar);
    public boolean isSelecionarAoEntrar();
    public int getColunas();
    public void setColunas(int colunas);
}
