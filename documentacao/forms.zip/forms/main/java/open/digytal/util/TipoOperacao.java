package open.digytal.util;

public enum TipoOperacao {
	INCLUSAO,
	ALTERACAO,
	EXCLUSAO,
	CONSULTA
}
