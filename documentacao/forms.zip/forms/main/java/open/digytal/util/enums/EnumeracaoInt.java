package open.digytal.util.enums;

public interface EnumeracaoInt extends Enumeracao {
	Integer getCodigo();
}