package open.digytal.util.model;

import java.util.Date;

public class Sessao {
	private Date inicio;
    private String login;
    private String usuario;
    private String role;
    private Integer empresa;
    private Integer armazem;
    private String nomeEmpresa;
	public Sessao(){
        this.inicio=new Date();
    }
	public Date getInicio() {
		return inicio;
	}
	public String getNomeEmpresa(){
		return nomeEmpresa==null?"NOVA EMPRESA":nomeEmpresa;
	}
	public Integer getEmpresa() {
		return empresa;
	}
	public void setEmpresa(Integer empresa) {
		this.empresa = empresa;
	}
	public Integer getArmazem() {
		return armazem;
	}
	public void setArmazem(Integer armazem) {
		this.armazem = armazem;
	}
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}
	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
