package open.digytal.util.desktop.ss;

public interface SSComponente {
}
