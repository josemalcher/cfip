package open.digytal.util.desktop.ss;


public class SSPainelRotulo extends SSComponenteRotulado {

    public SSPainelRotulo() {             
        super();
    }

    public String getText() {
        return null;
    }

    public void setText(String text) {
    }

    public boolean isEditavel() {
        return false;
    }

    public void setEditavel(boolean editavel) {
    }

    public Object getValue() {
        return null;
    }

    public void setValue(Object value) {
    }
}
