package open.digytal.util;

public class Formato {
	public static String MOEDA = "#,##0.00";
	public static String DATA = "dd/MM/yyyy";
	public static String CPF = "###.###.###-##";
	public static String CNPJ = "##.###.###/####-##";
	
}