package open.digytal.util.desktop.ss;

public enum SSPosicaoRotulo {
    ESQUERDA,
    TOPO;    
}
