package open.digytal.util.model;

import java.io.Serializable;

import open.digytal.model.Usuario;

public class Credencial implements Serializable {
    private String accessToken;
    private String tokenType = "Bearer";
    private Usuario usuario;
    public Credencial() {
    }
    public Credencial(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }
    public Usuario getUsuario() {
		return usuario;
	}
    public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
}
