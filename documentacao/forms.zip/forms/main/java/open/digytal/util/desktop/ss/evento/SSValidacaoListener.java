package open.digytal.util.desktop.ss.evento;

import java.util.EventListener;


public interface SSValidacaoListener  extends EventListener {
    public void validacaoListener(SSValidacaoEvento evento);
}
