package open.digytal.util.desktop.ss.evento;

import java.awt.*;


public class SSPesquisaEvento extends AWTEvent {    
    public SSPesquisaEvento(Object source) {
        super(source, 200802);        
    }
}
