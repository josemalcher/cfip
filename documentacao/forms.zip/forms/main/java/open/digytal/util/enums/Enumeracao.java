package open.digytal.util.enums;

public interface Enumeracao {
	String getNome();
}
