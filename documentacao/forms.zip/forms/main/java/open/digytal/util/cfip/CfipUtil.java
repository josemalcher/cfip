package open.digytal.util.cfip;

import java.util.List;

import open.digytal.model.cfip.Conta;
import open.digytal.model.cfip.Lancamento;
import open.digytal.model.cfip.TipoMovimento;
import open.digytal.model.cfip.Total;

public class CfipUtil {

    public static Total totais(List<Lancamento> lista) {
        return totais(lista, false);
    }

    public static Total totais(List<Lancamento> lista, boolean comTransferencia) {
        Total total = new Total();
        //FIXME:Como vc poderia melhorar este c�digo usando Lambda Java8 ?
        for (Lancamento l : lista) {
            if (comTransferencia || !l.isTransferencia())
                total.aplicar(l.getTipoMovimento() == TipoMovimento.CREDITO, l.getValor());
        }
        return total;
    }

    public static Double contaTotais(List<Conta> lista) {
        Double total = 0.0d;
        //FIXME:Como vc poderia melhorar este c�digo usando Lambda Java8 ?
        for (Conta c : lista) {
            total = total + c.getSaldo();
        }
        return total;
    }

}
