package open.digytal.desktop.cfip.teste;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JToolBar;
import open.digytal.util.desktop.BotaoIcone;
import javax.swing.JButton;
import open.digytal.util.desktop.ss.SSBotao;
import javax.swing.JComboBox;
import open.digytal.util.desktop.ss.SSCaixaCombinacao;
import java.awt.FlowLayout;
import open.digytal.util.desktop.ss.SSCampoTexto;
import javax.swing.border.EtchedBorder;

public class FrmConsulta extends JPanel {
	public FrmConsulta() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel topo = new JPanel();
		topo.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		add(topo, BorderLayout.NORTH);
		topo.setLayout(new BorderLayout(0, 0));
		
		JPanel filtros = new JPanel();
		FlowLayout flowLayout = (FlowLayout) filtros.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		topo.add(filtros, BorderLayout.CENTER);
		
		SSCaixaCombinacao caixaCombinacao = new SSCaixaCombinacao();
		filtros.add(caixaCombinacao);
		
		SSCampoTexto campoTexto = new SSCampoTexto();
		filtros.add(campoTexto);
		
		JToolBar botoes = new JToolBar();
		botoes.setFloatable(false);
		topo.add(botoes, BorderLayout.SOUTH);
		
		SSBotao btNovo = new SSBotao();
		btNovo.setText("Novo");
		botoes.add(btNovo);
		
		SSBotao btAlterar = new SSBotao();
		btAlterar.setText("Alterar");
		botoes.add(btAlterar);
		
		SSBotao btIncluir = new SSBotao();
		btIncluir.setText("Incluir");
		botoes.add(btIncluir);
		
		SSBotao btExcluir = new SSBotao();
		btExcluir.setText("Excluir");
		botoes.add(btExcluir);
	}

}
