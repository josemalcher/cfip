package open.digytal.desktop.cfip;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import open.digytal.SpringBootApp;
import open.digytal.service.AcessoService;
import open.digytal.util.ambiente.Configurador;
import open.digytal.util.desktop.DesktopApp;
import open.digytal.util.desktop.Login;
import open.digytal.util.desktop.ss.SSMensagem;
import open.digytal.util.model.Credencial;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FrmLogin extends Login {
	@Autowired
	private AcessoService service;
	public FrmLogin() {
		super.logar(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logarAction();
			}
		});
	}

	private void logarAction() {
		try {
			Credencial credencial = service.validarUsuario(getLogin());
			if (credencial.getUsuario()==null) {
				SSMensagem.avisa("Usuário não localizado");
				FrmUsuario frm = SpringBootApp.getBean(FrmUsuario.class);
				frm.setVisible(true);
			} else if (!service.validarSenha(getSenha(), credencial.getUsuario().getSenha())) {
				SSMensagem.avisa("Senha inválida");
			} else {
				DesktopApp.configurarSessao(credencial);
				Configurador.setCredencial(credencial);
				MDICfip mdi = SpringBootApp.getBean(MDICfip.class);
				mdi.exibirSessao();
				mdi.setVisible(true);
				this.dispose();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
