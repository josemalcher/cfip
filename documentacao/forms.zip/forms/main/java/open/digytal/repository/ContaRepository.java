package open.digytal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import open.digytal.model.cfip.Conta;

@Repository
public interface ContaRepository extends JpaRepository<Conta, Integer> {
    List<Conta> findByExcluidoFalseAndUsuario(String usuario);
    List<Conta> findByExcluidoFalseAndUsuarioAndNomeContaining(String usuario,String nome);
}
