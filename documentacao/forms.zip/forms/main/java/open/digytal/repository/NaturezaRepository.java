package open.digytal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import open.digytal.model.cfip.Conta;
import open.digytal.model.cfip.Natureza;
import open.digytal.model.cfip.TipoMovimento;

@Repository
public interface NaturezaRepository extends JpaRepository<Natureza, Integer> {
	List<Natureza> findByExcluidoFalseAndUsuario(String usuario);
	List<Natureza> findByExcluidoFalseAndUsuarioAndNomeContaining(String usuario,String nome);
	List<Natureza> findByExcluidoFalseAndUsuarioAndTipoMovimento(String usuario,TipoMovimento tipo);
}
