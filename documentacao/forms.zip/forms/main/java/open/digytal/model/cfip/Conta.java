package open.digytal.model.cfip;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity()
@Table(name="conta")
public class Conta implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(nullable=false,length=50)
	private String nome;
	
	@Column(nullable=false,length=20)
	private String sigla;
	
	@Column(nullable=false,length=9,precision=2)
	private Double saldo;
	
	@Column(length=9, precision=2)
	private Double custo;
	
	@Column(nullable=false)
	private boolean excluido;
	
	@Column(name="usuario_id", nullable=false, length=30)
	private String usuario;
	
	@Column(nullable=false)
	private boolean aplicacao;
	
	public void setAplicacao(boolean aplicacao) {
		this.aplicacao = aplicacao;
	}
	public boolean isAplicacao() {
		return aplicacao;
	}
	public Conta() {
		saldo=0.0d;
		custo=0.0d;
		aplicacao=false;
	}
	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}
	public boolean isExcluido() {
		return excluido;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public Double getSaldo() {
		return saldo;
	}
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Conta other = (Conta) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	public Double getCusto() {
		return custo;
	}
	public void setCusto(Double custo) {
		this.custo = custo;
	}
	
	@Override
	public String toString() {
		return "Conta{" +
				"id=" + id +
				", nome='" + nome + '\'' +
				", sigla='" + sigla + '\'' +
				", saldo=" + saldo +
				", excluido=" + excluido +
				", usuario='" + usuario + '\'' +
				", aplicacao=" + aplicacao +
				'}';
	}
}
