package open.digytal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="acs_usuario_config")
public class UsuarioConfiguracao {
    //insert into acs_usu_empresa (login, cd_empresa) values('a',1);;
    @Id
    @Column(name="id_usu_empresa")
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;
    @Column(name = "login",nullable = false, length = 30)
    private String login;
    @Column(name = "cd_empresa", nullable = false)
    private Integer empresa;
    @Column(name = "cd_armazem")
    private Integer armazem;

    public Integer getId() {
        return id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

   
	public Integer getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Integer empresa) {
		this.empresa = empresa;
	}

	public Integer getArmazem() {
		return armazem;
	}

	public void setArmazem(Integer armazem) {
		this.armazem = armazem;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UsuarioConfiguracao other = (UsuarioConfiguracao) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
    
}
