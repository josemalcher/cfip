package open.digytal.model.cfip;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class LancamentoComplemento {
	@Column(name="taxa_conversao", nullable=false, length = 9, precision = 2)
	private Double taxaConversao;
	
	@Column(name = "valor_principal", nullable = false, length = 9, precision = 2)
	private Double valorPrincipal;

	@Column(name = "juros_aliq", nullable = false, length = 9, precision = 2)
	private Double jurosAliquota;

	@Column(name = "multa_aliq", nullable = false, length = 9, precision = 2)
	private Double multaAliquota;

	@Column(name = "juros_valor", nullable = false, length = 9, precision = 2)
	private Double jurosValor;

	@Column(name = "multa_valor", nullable = false, length = 9, precision = 2)
	private Double multaValor;

	@Column(name = "desconto_aliq", nullable = false, length = 9, precision = 2)
	private Double descontoAliquota;

	@Column(name = "desconto_valor", nullable = false, length = 9, precision = 2)
	private Double descontoValor;

	@Column(name = "atualizacao_aliq", nullable = false, length = 9, precision = 2)
	private Double atualizacaoAliquota;

	@Column(name = "atualizacao_valor", nullable = false, length = 9, precision = 2)
	private Double atualizacaoValor;

	@Column(name = "parcela_inicial", nullable = false, length = 3)
	private Integer parcelaInicial;

	@Column(name = "parcela_final", nullable = false, length = 3)
	private Integer parcelaFinal;

	@Column(name = "parcelas", nullable = false, length = 3)
	private Integer parcelas;
	
	
	public LancamentoComplemento() {
		valorPrincipal = 0.0d;
		atualizacaoAliquota = 0.0d;
		atualizacaoValor = 0.0d;
		jurosAliquota = 0.0d;
		jurosValor = 0.0d;
		multaAliquota = 0.0d;
		multaValor = 0.0d;
		descontoAliquota = 0.0d;
		descontoValor = 0.0d;
		parcelas = 1;
		parcelaInicial = 1;
		parcelaFinal = 1;
		taxaConversao=0.0d;
	}

	public Double getTaxaConversao() {
		return taxaConversao;
	}

	public void setTaxaConversao(Double taxaConversao) {
		this.taxaConversao = taxaConversao;
	}

	public Double getValorPrincipal() {
		return valorPrincipal;
	}

	public void setValorPrincipal(Double valorPrincipal) {
		this.valorPrincipal = valorPrincipal;
	}

	public Double getJurosAliquota() {
		return jurosAliquota;
	}

	public void setJurosAliquota(Double jurosAliquota) {
		this.jurosAliquota = jurosAliquota;
	}

	public Double getMultaAliquota() {
		return multaAliquota;
	}

	public void setMultaAliquota(Double multaAliquota) {
		this.multaAliquota = multaAliquota;
	}

	public Double getJurosValor() {
		return jurosValor;
	}

	public void setJurosValor(Double jurosValor) {
		this.jurosValor = jurosValor;
	}

	public Double getMultaValor() {
		return multaValor;
	}

	public void setMultaValor(Double multaValor) {
		this.multaValor = multaValor;
	}

	public Double getDescontoAliquota() {
		return descontoAliquota;
	}

	public void setDescontoAliquota(Double descontoAliquota) {
		this.descontoAliquota = descontoAliquota;
	}

	public Double getDescontoValor() {
		return descontoValor;
	}

	public void setDescontoValor(Double descontoValor) {
		this.descontoValor = descontoValor;
	}

	public Double getAtualizacaoAliquota() {
		return atualizacaoAliquota;
	}

	public void setAtualizacaoAliquota(Double atualizacaoAliquota) {
		this.atualizacaoAliquota = atualizacaoAliquota;
	}

	public Double getAtualizacaoValor() {
		return atualizacaoValor;
	}

	public void setAtualizacaoValor(Double atualizacaoValor) {
		this.atualizacaoValor = atualizacaoValor;
	}

	public Integer getParcelaInicial() {
		return parcelaInicial;
	}

	
	public Integer getParcelaFinal() {
		return parcelaFinal;
	}

	public void setRangeParcelas(String rangeParcelas) {
		String[] iniFim = rangeParcelas.split("-");
		parcelaInicial=Integer.valueOf(iniFim[0].trim());
		parcelaFinal = Integer.valueOf(iniFim[1].trim());
	}
	public Integer getParcelas() {
		return parcelas;
	}

	public void setParcelas(Integer parcelas) {
		this.parcelas = parcelas;
	}
	
}
