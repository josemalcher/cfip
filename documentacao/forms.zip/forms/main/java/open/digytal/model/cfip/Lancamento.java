package open.digytal.model.cfip;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Lancamento implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "parcela", nullable = false, length = 3)
	private Integer parcela;

	@Enumerated(EnumType.STRING)
	@Column(name = "tipo_mov_id", nullable = false, length = 30)
	private TipoMovimento tipoMovimento;

	@ManyToOne
	@JoinColumn(name = "conta_id", nullable = false)
	private Conta conta;

	@ManyToOne
	@JoinColumn(name = "conta_destino_id")
	private Conta destino;

	@ManyToOne
	@JoinColumn(name = "natureza_id", nullable = false)
	private Natureza natureza;

	@Column(name = "usuario_id", nullable = false, length = 30)
	private String usuario;

	@Column(nullable = false, length = 500)
	private String descricao;

	@Temporal(TemporalType.DATE)
	@Column(nullable = false)
	private Date data;

	@Column(nullable = false, length = 6)
	private Integer periodo;
	
	@Column(nullable = false, length = 9, precision = 2)
	private Double valor;
	
	@ManyToOne
	@JoinColumn(name = "contato_id")
	private Contato contato;
	
	@Column(nullable=false,length=1)
	private boolean transferencia;

	@Column(nullable=false,length=1)
	private boolean previsao;
	
	@Column(nullable=false,length=1)
	private boolean excluido;

	@Temporal(TemporalType.DATE)
	private Date quitacao;
	
	@Column(name = "periodo_quitacao", length = 6)
	private Integer periodoQuitacao;
	
	@Column(name = "lancto_origem_id", length = 9)
	private Integer origemLancamento;
	
	@Embedded
	private LancamentoComplemento complemento;
	public Lancamento() {
		valor = 0.0d;
		data = new Date();
		valor = 0.0d;
		parcela = 1;
		tipoMovimento = TipoMovimento.CREDITO;
		complemento = new LancamentoComplemento();
	}
	public LancamentoComplemento getComplemento() {
		return complemento;
	}
	public void setComplemento(LancamentoComplemento complemento) {
		this.complemento = complemento;
	}

	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}

	public boolean isExcluido() {
		return excluido;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public Natureza getNatureza() {
		return natureza;
	}

	public void setNatureza(Natureza natureza) {
		this.natureza = natureza;
	}

	public TipoMovimento getTipoMovimento() {
		return tipoMovimento;
	}

	public void setTipoMovimento(TipoMovimento tipoMovimento) {
		this.tipoMovimento = tipoMovimento;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public void calcularValorAtual() {
		if (tipoMovimento == TipoMovimento.CREDITO)
			valor = complemento.getValorPrincipal() +  complemento.getMultaValor() +  complemento.getJurosValor() +  complemento.getAtualizacaoValor() -  complemento.getDescontoValor();
		else if (tipoMovimento == TipoMovimento.DEBITO)
			valor =  complemento.getValorPrincipal() -  complemento.getMultaValor() -  complemento.getJurosValor() -  complemento.getAtualizacaoValor() +  complemento.getDescontoValor();
	}

	public boolean isPrevisao() {
		return previsao;
	}

	public void setPrevisao(boolean previsao) {
		this.previsao = previsao;
	}

	public Date getQuitacao() {
		return quitacao;
	}

	public void setQuitacao(Date quitacao) {
		this.quitacao = quitacao;
	}

	public Integer getPeriodo() {
		return periodo;
	}

	public void setPeriodo(Integer periodo) {
		this.periodo = periodo;
	}

	public Integer getPeriodoQuitacao() {
		return periodoQuitacao;
	}

	public void setPeriodoQuitacao(Integer periodoQuitacao) {
		this.periodoQuitacao = periodoQuitacao;
	}

	public boolean isTransferencia() {
		return transferencia;
	}

	public void setTransferencia(boolean transferencia) {
		this.transferencia = transferencia;
	}

	public Lancamento copia() {
		Lancamento copia = new Lancamento();
		copia.setConta(conta);
		copia.setData(data);
		copia.setDescricao(descricao);
		copia.setDestino(destino);
		copia.setExcluido(excluido);
		copia.setId(id);
		copia.setNatureza(natureza);
		copia.setPeriodo(periodo);
		copia.setPeriodoQuitacao(periodoQuitacao);
		copia.setPrevisao(previsao);
		copia.setQuitacao(quitacao);
		copia.setTipoMovimento(tipoMovimento);
		copia.setTransferencia(transferencia);
		copia.setUsuario(usuario);
		copia.setValor(valor);
		copia.setParcela(parcela);
		copia.setContato(contato);
		
		LancamentoComplemento copiaComplemeto = copia.getComplemento();
		copiaComplemeto.setValorPrincipal( valor);
		copiaComplemeto.setParcelas(complemento.getParcelas());
		copiaComplemeto.setTaxaConversao(complemento.getTaxaConversao());
		copiaComplemeto.setAtualizacaoAliquota(complemento.getAtualizacaoAliquota());
		copiaComplemeto.setAtualizacaoValor(complemento.getAtualizacaoValor());
		copiaComplemeto.setDescontoAliquota(complemento.getDescontoAliquota());
		copiaComplemeto.setDescontoValor(complemento.getDescontoValor());
		copiaComplemeto.setJurosAliquota(complemento.getJurosAliquota());
		copiaComplemeto.setJurosValor(complemento.getJurosValor());
		copiaComplemeto.setMultaAliquota(complemento.getMultaAliquota());
		copiaComplemeto.setMultaValor(complemento.getMultaValor());
		
		// copia.setFatura(fatura);
		copia.setOrigemLancamento(origemLancamento);
		return copia;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lancamento other = (Lancamento) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public Contato getContato() {
		return contato;
	}

	public void setContato(Contato contato) {
		this.contato = contato;
	}

	public Conta getDestino() {
		return destino;
	}

	public void setDestino(Conta destino) {
		this.destino = destino;
	}

	public Integer getParcela() {
		return parcela;
	}

	public void setParcela(Integer parcela) {
		this.parcela = parcela;
	}

	public Integer getOrigemLancamento() {
		return origemLancamento;
	}

	public void setOrigemLancamento(Integer origemLancamento) {
		this.origemLancamento = origemLancamento;
	}

}
