package open.digytal.service;

public interface Controle {
	String API = "API";
	String JPA = "JPA";
	
	//<T> T salvar(T entidade);
	/*<T> T buscar(Class classe, Object id);
	<T> T buscar(Class classe, Object id,boolean novo) throws InstantiationException, IllegalAccessException;
	<T> List<T> listarTodos(Class classe);
	<T> List<T> listar(Class classe, Filtro... filtros);*/
}
