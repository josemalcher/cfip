package open.digytal.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import open.digytal.model.Usuario;
import open.digytal.repository.UsuarioRepository;
import open.digytal.service.UsuarioService;

@Service
public class UsuarioControl implements UsuarioService {
	@Autowired
	private UsuarioRepository repository; 
	@Override
	public Usuario buscarLogin(String login) {
		Optional<Usuario> entidade = repository.findByLogin(login);
		return entidade.isPresent()?entidade.get():null;
	}

	@Override
	public boolean existeLogin(String login) {
		return repository.existsByLogin(login);
	}

	@Override
	public boolean existeEmail(String email) {
		return repository.existsByEmail(email);
	}
	public Usuario salvar(Usuario entidade) {
		return repository.save(entidade);
	}
}
