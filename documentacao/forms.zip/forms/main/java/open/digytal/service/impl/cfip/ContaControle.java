package open.digytal.service.impl.cfip;

import java.util.Collections;
import java.util.List;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import open.digytal.model.Role;
import open.digytal.model.Roles;
import open.digytal.model.Usuario;
import open.digytal.model.cfip.Categoria;
import open.digytal.model.cfip.Conta;
import open.digytal.model.cfip.Natureza;
import open.digytal.model.cfip.TipoMovimento;
import open.digytal.persistencia.Repositorio;
import open.digytal.repository.ContaRepository;
import open.digytal.service.Controle;
import open.digytal.service.RoleService;
import open.digytal.service.cfip.ContaService;

@Service
@Profile(Controle.JPA)
public class ContaControle implements ContaService {
    @Autowired
    private ContaRepository repository;
    
    @Autowired
	private Repositorio repositorio;
    
    @Autowired
	private RoleService roleService;
    
	@Transactional
    public Conta salvar(Conta entidade) {
        return repository.save(entidade);
    }

    public List<Conta> listar(String usuario) {
       return repository.findByExcluidoFalseAndUsuario(usuario);
    }

    public List<Conta> listar(String usuario, String nome) {
       /* Query query = getEntityManager().createQuery("SELECT e FROM Conta e WHERE e.excluido = false and e.usuario = :usuario and e.nome like :nome");
        query.setParameter("usuario", usuario);
        query.setParameter("nome", "%" + nome + "%");
        return query.getResultList();*/
    	return repository.findByExcluidoFalseAndUsuarioAndNomeContaining(usuario, nome);
    }

    public List<Conta> listar(String usuario,Integer id) {
       StringBuilder sql = new StringBuilder("SELECT e FROM Conta e WHERE e.aplicacao = false AND e.excluido = false AND saldo >0 AND  e.usuario = :usuario");
        if(id!=null && id > 0)
            sql.append(" AND e.id = :id");
        sql.append(" ORDER BY e.nome");
        Query query = repositorio.getEntityManager().createQuery(sql.toString());
        query.setParameter("usuario", usuario);
        if(id!=null && id > 0)
            query.setParameter("id", id);

        return query.getResultList();
    }
   
    @Transactional
    public Usuario incluirUsuario(Usuario usuario) {
    	for(Roles r: Roles.values()) {
        	Role role = roleService.buscar(r.name());
        	if(role==null) {
    			role = new Role();
    			role.setNome(r.name());
    			roleService.salvar(role);
    		}
        }
    	Role role = roleService.buscar(Roles.ROLE_USER.name());
        if(usuario.getRoles().isEmpty())
        	usuario.setRoles(Collections.singleton(role));
        
    	repositorio.incluir(usuario);
        Conta conta = new Conta();
        conta.setNome("CARTEIRA");
        conta.setSigla("CTR");
        conta.setUsuario(usuario.getLogin());
        conta = repositorio.alterar(conta);
        
        conta = new Conta();
        conta.setNome("CONTA CORRENTE");
        conta.setSigla("CCR");
        conta.setUsuario(usuario.getLogin());
        conta = repositorio.alterar(conta);
        
        conta = new Conta();
        conta.setNome("CONTA POUPANCA");
        conta.setSigla("CPA");
        conta.setUsuario(usuario.getLogin());
        conta = repositorio.alterar(conta);
        
        Natureza natureza = new Natureza();
        natureza.setDescricao("SALDO INICIAL");
        natureza.setNome("SALDO INICIAL");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.CREDITO);
        natureza.setCategoria(Categoria.REMUNERACAO);
        repositorio.incluir(natureza);

        natureza = new Natureza();
        natureza.setDescricao("SALARIO");
        natureza.setNome("SALARIO");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.CREDITO);
        natureza.setCategoria(Categoria.REMUNERACAO);
        repositorio.incluir(natureza);

        natureza = new Natureza();
        natureza.setDescricao("DESPEAS");
        natureza.setNome("DESPESAS");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.DEBITO);
        natureza.setCategoria(Categoria.DESPESA);
        repositorio.incluir(natureza);

        natureza = new Natureza();
        natureza.setDescricao("TRANSFERENCIA");
        natureza.setNome("TRANSFERENCIA");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.TRANSFERENCIA);
        natureza.setCategoria(Categoria.TRANSACOES);
        repositorio.incluir(natureza);

        natureza = new Natureza();
        natureza.setDescricao("ESTORNO DA TRANSFERENCIA");
        natureza.setNome("ESTORNO");
        natureza.setUsuario(usuario.getLogin());
        natureza.setTipoMovimento(TipoMovimento.TRANSFERENCIA);
        repositorio.incluir(natureza);
        
        
        return usuario;
    	
    }

}
