package open.digytal.service.impl.cfip;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import open.digytal.model.cfip.Natureza;
import open.digytal.model.cfip.TipoMovimento;
import open.digytal.repository.NaturezaRepository;
import open.digytal.service.Controle;
import open.digytal.service.cfip.NaturezaService;

@Service
@Profile(Controle.JPA)
public class NaturezaControle implements NaturezaService {
	@Autowired
	private NaturezaRepository repository; 
    public List<Natureza> listarNaturezas(String usuario, String nome) {
       /* Query query = getEntityManager().createQuery(
                "SELECT e FROM Natureza e WHERE e.excluido = false and e.usuario = :usuario AND e.nome LIKE :nome ORDER BY e.nome");
        query.setParameter("usuario", usuario);
        query.setParameter("nome", "%" + nome + "%");
        return query.getResultList();*/
    	return repository.findByExcluidoFalseAndUsuarioAndNomeContaining(usuario, nome);
    }

    public List<Natureza> listarNaturezas(String usuario) {
        /*Query query = getEntityManager().createQuery(
                "SELECT e FROM Natureza e WHERE e.excluido = false and e.usuario = :usuario ORDER BY e.tipoMovimento, e.nome");
        query.setParameter("usuario", usuario);
        return query.getResultList();*/
    	
    	return repository.findByExcluidoFalseAndUsuario(usuario);
    }

    public List<Natureza> listarNaturezas(String usuario, TipoMovimento tipo) {
       /* Query query = getEntityManager().createQuery(
                "SELECT e FROM Natureza e WHERE e.excluido = false AND e.usuario = :usuario AND e.tipoMovimento=:tipoMovto ORDER BY e.nome");
        query.setParameter("usuario", usuario);
        query.setParameter("tipoMovto", tipo);
        return query.getResultList();*/
    	return repository.findByExcluidoFalseAndUsuarioAndTipoMovimento(usuario, tipo);
    }

	@Override
	public Natureza salvar(Natureza entidade) {
		return repository.save(entidade);
	}
}
