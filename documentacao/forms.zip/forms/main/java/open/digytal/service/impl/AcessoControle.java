package open.digytal.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import open.digytal.model.Role;
import open.digytal.model.Usuario;
import open.digytal.repository.RoleRepository;
import open.digytal.repository.UsuarioRepository;
import open.digytal.service.AcessoService;
import open.digytal.service.Controle;
import open.digytal.util.model.Credencial;

@Service
@Profile(Controle.JPA)
public class AcessoControle  implements AcessoService {
	@Autowired
	private UsuarioRepository repositorio;
	
	@Autowired
	private RoleRepository roleRepositorio;
	
	@Autowired
	private PasswordEncoder encoder;

	@Override
	public Credencial logar(String login,String senha) {
		return null; 
	}
	@Override
	public Credencial validarUsuario(String login) {
		Optional<Usuario> entidade = repositorio.findByLogin(login);
		Credencial credencial = new Credencial();
		if(entidade.isPresent()){
			Usuario usuario = entidade.get();
			credencial.setUsuario(usuario);
		}
		return credencial; 
	}
	@Override
	public boolean validarSenha(String senhaInformada, String senhaCriptografada) {
		return encoder.matches(senhaInformada, senhaCriptografada);
	}
	@Override
	public boolean existeLogin(String login) {
		return repositorio.existsByLogin(login);
	}

	@Override
	public boolean existeEmail(String email) {
		return repositorio.existsByEmail(email);
	}

	@Override
	public Optional<Role> role(String nome) {
		return roleRepositorio.findByNome(nome);
	}

	@Override
	public Usuario salvar(Usuario entidade) {
		return repositorio.save(entidade);
	}

	@Override
	public Optional<Usuario> buscar(Long id) {
		return repositorio.findById(id);
	}

	@Override
	public Optional<Usuario> buscar(String login) {
		return repositorio.findByLogin(login);
	}
	
}
