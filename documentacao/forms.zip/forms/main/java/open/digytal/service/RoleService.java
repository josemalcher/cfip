package open.digytal.service;

import java.util.List;

import open.digytal.model.Role;
public interface RoleService {
	Role salvar(Role entidade);
	Role buscar(Integer id);
	Role buscar(String nome);
	List<Role> listar();
}
