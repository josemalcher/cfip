package open.digytal.service.cfip;

import java.util.List;

import open.digytal.model.cfip.Natureza;
import open.digytal.model.cfip.TipoMovimento;
import open.digytal.service.Controle;

public interface NaturezaService extends Controle {
	Natureza salvar(Natureza entidade);
    List<Natureza> listarNaturezas(String usuario, String nome);

    List<Natureza> listarNaturezas(String usuario);

    List<Natureza> listarNaturezas(String usuario, TipoMovimento tipo);
}
