package open.digytal.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import open.digytal.model.Role;
import open.digytal.persistencia.Repositorio;
import open.digytal.repository.RoleRepository;
import open.digytal.service.RoleService;

@Service
public class RoleControl implements RoleService {
	@Autowired
	private RoleRepository repository;
	
	@Autowired
	private Repositorio repositorio;
	
	@Override
	public Role buscar(Integer id) {
		Optional<Role> entidade = repository.findById(id);
		return entidade.isPresent()?entidade.get():null;
	}
	public Role salvar(Role entidade) {
		return repository.save(entidade);
	}
	@Override
	public List<Role> listar() {
		//select 'Nome::' + e.nome, 'id::' + e.id  from asdasdas 
		
		String campos="e.nome AS Nome, e.id AS Id";
		String sql="SELECT " + campos  +" FROM Role e ";
		List<Object[]> registros = repositorio.getEntityManager().createQuery(sql).getResultList();
		return repositorio.converter(campos, Role.class, registros);
	}
	@Override
	public Role buscar(String nome) {
		Optional<Role> entidade = repository.findByNome(nome);
		return entidade.isPresent()?entidade.get():null;
	}
}
