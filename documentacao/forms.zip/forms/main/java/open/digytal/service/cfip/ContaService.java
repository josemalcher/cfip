package open.digytal.service.cfip;

import java.util.List;

import open.digytal.model.Usuario;
import open.digytal.model.cfip.Conta;
import open.digytal.service.Controle;

public interface ContaService extends Controle {
	Conta salvar(Conta entidade);

	List<Conta> listar(String usuario);

	List<Conta> listar(String usuario, String nome);

	List<Conta> listar(String usuario, Integer id);

	Usuario incluirUsuario(Usuario usuario);

	// List<Contato> listarContatos(String usuario, String nome);

	// List<Contato> listarContatos(String usuario);

	// List<DespesaRapida> listarDespesasRapidas(String usuario);
}
