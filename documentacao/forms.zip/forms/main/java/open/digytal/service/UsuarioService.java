package open.digytal.service;

import open.digytal.model.Usuario;

public interface UsuarioService {
	Usuario salvar(Usuario entidade);
	Usuario buscarLogin(String login);
    boolean existeLogin(String login);
    boolean existeEmail(String email);
}
