package open.digytal.service.cfip;

import java.util.Date;
import java.util.List;

import open.digytal.model.cfip.Lancamento;
import open.digytal.service.Controle;

public interface LancamentoService extends Controle {
	Lancamento buscar(Integer id);
	
	Lancamento salvar(Lancamento entidade);
	
	List<Lancamento> listarLancamentos(String usuario, Date inicio, Date fim, Integer conta, Integer natureza);

	List<Lancamento> listarPrevisoes(String usuario, Date inicio, Date fim, Integer conta, Integer natureza);

	List<Lancamento> listarContaLancamentos(String usuario, Date inicio, Date fim, Integer conta);

	void incluirLancamento(Lancamento entidade);

	void compensarLancamento(Integer id, Date quitacao);

	void compensarLancamento(Date quitacao, Integer... ids);

	void amortizarLancamento(Integer id, Date quitacao, Double amortizado);
}
