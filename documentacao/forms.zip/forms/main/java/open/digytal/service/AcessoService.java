package open.digytal.service;

import java.util.Optional;

import open.digytal.model.Role;
import open.digytal.model.Usuario;
import open.digytal.util.model.Credencial;

public interface AcessoService{
	Optional<Role> role(String nome);
	@Deprecated
	Credencial logar(String login,String senha);
	Credencial validarUsuario(String login);
    boolean validarSenha(String senhaInformada, String senhaCriptografada);
	Usuario salvar(Usuario entidade);
    Optional<Usuario> buscar(Long id);
    Optional<Usuario> buscar(String login);
	
    boolean existeLogin(String login);
    boolean existeEmail(String email);
}
