package open.digytal;

import javax.swing.UIManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import open.digytal.service.Controle;
import open.digytal.util.ambiente.Configurador;
import open.digytal.util.desktop.DesktopApp;
import open.digytal.util.desktop.Login;

/**
 * Se não quiser usar SpringBoot para gerenciar o projeto e persistencia
 *
 * @SpringBootApplication(exclude = { DataSourceAutoConfiguration.class,
 *                                DataSourceTransactionManagerAutoConfiguration.class,
 *                                HibernateJpaAutoConfiguration.class})
 * @ComponentScan(basePackages = {"open.digytal.desktop",...}) @EntityScan(
 *                             basePackages = {"open.digytal.model"} )
 */

@SpringBootApplication
public class SpringBootApp extends DesktopApp {
	private static ApplicationContext contexto;

	public static void main(String[] args) {
		try {
			String lf = UIManager.getSystemLookAndFeelClassName();
			UIManager.setLookAndFeel(lf);
			init(args);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	private static void init(String[] args) {
		Configurador.configurarAmbiente("DIGYTAL", "CFIP");
		DesktopApp.exibirSplash();
		SpringApplicationBuilder builder = new SpringApplicationBuilder(SpringBootApp.class);
		builder.headless(false);
		//Todos os componentes estão configurados para um PROFILE
		builder.profiles(Controle.JPA);
		contexto = builder.run(args);
		DesktopApp.fecharSplash();
		Login login = contexto.getBean(Login.class);
		login.exibir();

	}

	public static <T> T getBean(Class classe) {
		return (T) contexto.getBean(classe);
	}

	@Bean
	public PasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}
}
